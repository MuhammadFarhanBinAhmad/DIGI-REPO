#define TEST_CASE 0 
//                ^ Set this number to the test case you want

#if TEST_CASE == 1
    #include "1-type_traits.h"
#elif TEST_CASE == 2
    #include "2-removecvref_eg.h"
#elif TEST_CASE == 3
    #include "3-removecvref_soln.h"
#elif TEST_CASE == 4
    #include "4-ifconstexpr.h"
#elif TEST_CASE == 5
    #include "5-static_assert.h"
#elif TEST_CASE == 6
    #include "6-static_assert_soln.h"
#elif TEST_CASE == 7
    #include "7-static_assert_concept.h"
#elif TEST_CASE == 8
    #include "8-varargs.h"
#elif TEST_CASE == 9
    #include "9-fold.h"
#elif TEST_CASE == 10
    #include "10-varargs-soln.h"
#else
    #error "Please select a valid test case by setting TEST_CASE between 1 - 10 in main.cpp"
#endif