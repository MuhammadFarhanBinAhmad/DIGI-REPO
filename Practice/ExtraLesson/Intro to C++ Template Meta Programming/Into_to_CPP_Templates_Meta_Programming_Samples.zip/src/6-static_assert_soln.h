/*!
@file       6-static_assert_soln.h
@author     Tng Kah Wei (kahwei.tng@digipen.edu)
@date       12 Aug 2023
@brief      Demonstrates how using static_assert can give more useful errors.

            Comment away line 35 and compile to see the clearer error we present to the
            user using static_assert.
*//*___________________________________________________________________________________*/
#pragma once

#include <iostream>
#include <type_traits>
#include "Vectors.h"

/*-------------------------------------------------------------------------------------*/
/* Main Focus                                                                          */
/*-------------------------------------------------------------------------------------*/
template<typename T>
float sumXChannel(const T* begin, const T* end)
{
    static_assert(std::is_same_v<T, Vec3>, "Only Vec3 is supported.");

    float sum = 0.0f;
    for (const T* iter = begin; iter != end; ++iter)
    {
        sum += iter->x;
    }
    return sum;
}

/*-------------------------------------------------------------------------------------*/
/* Config                                                                              */
/*-------------------------------------------------------------------------------------*/
#define USE_VEC

/*-------------------------------------------------------------------------------------*/
/* Test Code                                                                           */
/*-------------------------------------------------------------------------------------*/
int main()
{
    constexpr int SIZE = 7;

#ifdef USE_VEC
    const Vec3 DATA[SIZE] =
    {
        Vec3(42.0f, 2.0f, 3.0f),
        Vec3(69.0f, 2.0f, 3.0f),
        Vec3(42.0f, 2.0f, 3.0f),
        Vec3(14.0f, 2.0f, 3.0f),
        Vec3(31.0f, 2.0f, 3.0f),
        Vec3(21.0f, 2.0f, 3.0f),
        Vec3(13.0f, 2.0f, 3.0f)
    };
#else
    const float DATA[SIZE] =
    {
       1.0f, 2.0f, 3.0f, 4.0f,  1.0f, 5.0f, 12.0f
    };
#endif
    std::cout << "Sum: " << sumXChannel(&DATA[0], &DATA[SIZE]) << std::endl;
}
