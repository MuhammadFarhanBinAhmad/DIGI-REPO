/*!
@file       8-varargs.h
@author     Tng Kah Wei (kahwei.tng@digipen.edu)
@date       12 Aug 2023
@brief      Demonstration of a scenario where template variadic arguments can make
            an API more concise.
*//*___________________________________________________________________________________*/
#pragma once

#include <iostream>
#include <unordered_map>
#include <vector>

using OBJ_ID = int;
using MSG_TYPE = int;

namespace
{
    std::unordered_map<MSG_TYPE, std::vector<OBJ_ID>> subscribers;

    void subscribe(OBJ_ID sub, MSG_TYPE m)
    {
        subscribers[m].push_back(sub);
    }
}


int main()
{
    // Subscribe here
    OBJ_ID a = 0, b = 1, c = 2;
    subscribe(a, 1);
    subscribe(a, 2);
    subscribe(a, 3);
    subscribe(b, 1);
    subscribe(b, 22);
    subscribe(b, 23);
    subscribe(c, 31);
    subscribe(c, 2);
    subscribe(c, 3);

    // Print out subscribers
    for (const auto& pair : subscribers)
    {
        std::cout << "[" << pair.first << "] = { ";

        for (auto sub : pair.second)
        {
            std::cout << sub << " ";
        }

        std::cout << "}" << std::endl;
    }
}