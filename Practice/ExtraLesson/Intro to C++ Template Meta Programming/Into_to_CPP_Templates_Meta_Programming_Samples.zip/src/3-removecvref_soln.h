/*!
@file       3-removecvref_soln.h
@author     Tng Kah Wei (kahwei.tng@digipen.edu)
@date       12 Aug 2023
@brief      Demonstrates how std::removecvref_t<T> solves issue with forwarding
            references.
*//*___________________________________________________________________________________*/
#pragma once

#include <iostream>
#include <type_traits>

template<typename T>
bool isInt(T&& val) // Forwarding Reference!
{
    using Type = std::remove_cvref_t<T>;
    return std::is_same_v<int, Type>;
}


int main()
{
    const int A = 5;
    const int& X = 5;

    std::cout << std::boolalpha;
    std::cout << "isInt(5): " << isInt(5) << std::endl; // True or False?
    std::cout << "isInt(A): " << isInt(A) << std::endl; // True or False?
    std::cout << "isInt(X): " << isInt(X) << std::endl; // True or False?
}