/*!
@file       4-ifconstexpr.h
@author     Tng Kah Wei (kahwei.tng@digipen.edu)
@date       12 Aug 2023
@brief      Demonstrates how if constexpr can be used to compile code based on
            type traits.
*//*___________________________________________________________________________________*/
#pragma once

#include <iostream>
#include <iomanip>
#include <type_traits>
#include <limits>

/*-------------------------------------------------------------------------------------*/
/* Helper Constants                                                                    */
/*-------------------------------------------------------------------------------------*/
constexpr float EPSILON = 0.000001f;

/*-------------------------------------------------------------------------------------*/
/* Helper Functions                                                                    */
/*-------------------------------------------------------------------------------------*/
float additiveMult(float f, int n)
{
    float result = 0;
    for (int i = 0; i < n; ++i)
        result += f;
    return result;
}

/*-------------------------------------------------------------------------------------*/
/* Main Focus                                                                          */
/*-------------------------------------------------------------------------------------*/
template<typename T>
bool equals(T a, T b)
{
    return a == b;
}

template<typename T>
bool fixedEquals(T a, T b)
{
    if constexpr (std::is_floating_point_v<T>)
        return std::abs(a - b) < EPSILON;
    else
        return a == b;
}

/*-------------------------------------------------------------------------------------*/
/* Test Cases                                                                          */
/*-------------------------------------------------------------------------------------*/
int main()
{
    const float F1 = additiveMult(0.01f, 11);
    const float F2 = 0.01f * 11;

    std::cout << std::fixed << std::setprecision(6);
    std::cout << "\nValues" << std::endl;
    std::cout << "--------" << std::endl;
    std::cout << "F1 (0.01 + ... + 0.01): " << F1 << std::endl;
    std::cout << "F2 (0.01 * 11)        : " << F2 << std::endl;

    std::cout << std::boolalpha;
    std::cout << "\nequals()" << std::endl;
    std::cout << "--------" << std::endl;
    std::cout << "(F1, F1): " << equals(F1, F1) << std::endl;
    std::cout << "(1 , 1 ): " << equals(1, 1) << std::endl;
    std::cout << "(F1, F2): " << equals(F1, F2) << std::endl;
    std::cout << "(1 , 0 ): " << equals(1, 01) << std::endl;

    std::cout << "\nfixedEquals()" << std::endl;
    std::cout << "--------" << std::endl;
    std::cout << "(F1, F1): " << fixedEquals(F1, F1) << std::endl;
    std::cout << "(1 , 1 ): " << fixedEquals(1, 1) << std::endl;
    std::cout << "(F1, F2): " << fixedEquals(F1, F2) << std::endl;
    std::cout << "(1 , 0 ): " << fixedEquals(1, 01) << std::endl;
}