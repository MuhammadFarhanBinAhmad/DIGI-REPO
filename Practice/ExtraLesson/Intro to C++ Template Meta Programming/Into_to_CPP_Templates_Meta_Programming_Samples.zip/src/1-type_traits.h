/*!
@file       1-type_traits.h
@author     Tng Kah Wei (kahwei.tng@digipen.edu)
@date       12 Aug 2023
@brief      Demonstrates built-in std type traits.
*//*___________________________________________________________________________________*/
#pragma once

#include <iostream>
#include <type_traits>

int main()
{
    std::cout << std::boolalpha;
    std::cout << "std::is_floating_point_v" << std::endl;
    std::cout << "--------" << std::endl;
    std::cout << "<float >: " << std::is_floating_point_v<float> << std::endl;
    std::cout << "<double>: " << std::is_floating_point_v<double> << std::endl;
    std::cout << "<int   >: " << std::is_floating_point_v<int> << std::endl;
    std::cout << "<short >: " << std::is_floating_point_v<short> << std::endl;
    std::cout << "<char  >: " << std::is_floating_point_v<char> << std::endl;
    std::cout << "<bool  >: " << std::is_floating_point_v<bool> << std::endl;

    std::cout << "\nstd::is_arithmetic_v" << std::endl;
    std::cout << "--------" << std::endl;
    std::cout << "<float >: " << std::is_arithmetic_v<float> << std::endl;
    std::cout << "<double>: " << std::is_arithmetic_v<double> << std::endl;
    std::cout << "<int   >: " << std::is_arithmetic_v<int> << std::endl;
    std::cout << "<short >: " << std::is_arithmetic_v<short> << std::endl;
    std::cout << "<char  >: " << std::is_arithmetic_v<char> << std::endl;
    std::cout << "<bool  >: " << std::is_arithmetic_v<bool> << std::endl;

    std::cout << "\nstd::is_same_v" << std::endl;
    std::cout << "--------" << std::endl;
    std::cout << "<float    , int  >: " << std::is_same_v<float, int> << std::endl;
    std::cout << "<float    , float>: " << std::is_same_v<float, float> << std::endl;
    std::cout << "<const int, int  >: " << std::is_same_v<const int, int> << std::endl;
    std::cout << "<int&     , int  >: " << std::is_same_v<int&, int> << std::endl;
}