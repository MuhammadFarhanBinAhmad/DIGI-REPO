/*!
@file       7-static_assert_concept.h
@author     Tng Kah Wei (kahwei.tng@digipen.edu)
@date       12 Aug 2023
@brief      Sneak peek on how concepts can make the previous example 
            (6-static_assert_soln.h) can be generalised using C++ 20 Concepts.

            Change the MODE macro on line 46 to either MODE_VEC2, MODE_VEC3 or MODE_FLOAT
            to see how the static_assert with concept handles different types.
*//*___________________________________________________________________________________*/
#pragma once

#include <iostream>
#include <type_traits>
#include "Vectors.h"

/*-------------------------------------------------------------------------------------*/
/* Main Focus                                                                          */
/*-------------------------------------------------------------------------------------*/
template<typename T>
concept has_float_x = requires (T x)
{
    { x.x } -> std::same_as<float&>;
};


template<typename T>
float sumXChannel(const T* begin, const T* end)
{
    static_assert(has_float_x<T>, "Supports only structs that contain an x component of type float.");

    float sum = 0.0f;
    for (const T* iter = begin; iter != end; ++iter)
    {
        sum += iter->x;
    }
    return sum;
}

/*-------------------------------------------------------------------------------------*/
/* Config                                                                              */
/*-------------------------------------------------------------------------------------*/
#define MODE_VEC2 0
#define MODE_VEC3 1
#define MODE_FLOAT 2
#define MODE MODE_VEC2

/*-------------------------------------------------------------------------------------*/
/* Test Code                                                                           */
/*-------------------------------------------------------------------------------------*/
int main()
{
    constexpr int SIZE = 7;

#if MODE == MODE_VEC2
    const Vec2 DATA[SIZE] =
    {
        Vec2(42.0f, 2.0f),
        Vec2(69.0f, 2.0f),
        Vec2(42.0f, 2.0f),
        Vec2(14.0f, 2.0f),
        Vec2(31.0f, 2.0f),
        Vec2(21.0f, 2.0f),
        Vec2(13.0f, 2.0f)
    };
#elif MODE == MODE_VEC3
    const Vec3 DATA[SIZE] =
    {
        Vec3(42.0f, 2.0f, 3.0f),
        Vec3(69.0f, 2.0f, 3.0f),
        Vec3(42.0f, 2.0f, 3.0f),
        Vec3(14.0f, 2.0f, 3.0f),
        Vec3(31.0f, 2.0f, 3.0f),
        Vec3(21.0f, 2.0f, 3.0f),
        Vec3(13.0f, 2.0f, 3.0f)
    };
#elif MODE == MODE_FLOAT
    const float DATA[SIZE] =
    {
       1.0f, 2.0f, 3.0f, 4.0f,  1.0f, 5.0f, 12.0f
    };
#else 
    #error "Select a valid mode."
#endif

    std::cout << "Sum: " << sumXChannel(&DATA[0], &DATA[SIZE]) << std::endl;
}
