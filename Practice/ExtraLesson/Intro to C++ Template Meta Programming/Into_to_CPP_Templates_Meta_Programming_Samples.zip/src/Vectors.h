/*!
@file       2-removecvref_eg.h
@author     Tng Kah Wei (kahwei.tng@digipen.edu)
@date       12 Aug 2023
@brief      Simple Vector structs for use in tests.
*//*___________________________________________________________________________________*/
#pragma once

struct Vec2
{
    float x, y, z;
};

struct Vec3
{
    float x, y, z;
};
