/*!
@file       9-fold.h
@author     Tng Kah Wei (kahwei.tng@digipen.edu)
@date       12 Aug 2023
@brief      Demonstration of fold expressions in different use cases and types of fold
            expressions.
*//*___________________________________________________________________________________*/
#pragma once

#include <iostream>

/*-------------------------------------------------------------------------------------*/
/* Simple Function-Based Fold Expression                                               */
/*-------------------------------------------------------------------------------------*/
void simplePrint(const std::string& s)
{
    std::cout << s << " ";
}

template<typename ... Args>
void simplePrintLine(Args ... msg)
{
    (simplePrint(msg), ...);
    std::cout << std::endl;
}

/*-------------------------------------------------------------------------------------*/
/* Expression-Based Fold Expression                                                    */
/*-------------------------------------------------------------------------------------*/
template<typename ... Args>
void print(Args ... msg)
{
    ((std::cout << msg << " "), ...);
}

/*-------------------------------------------------------------------------------------*/
/* Operator-Based Fold Expression                                                      */
/*-------------------------------------------------------------------------------------*/
template<typename ... Args>
float add(Args ... vals)
{
    return (vals + ...);
}

/*-------------------------------------------------------------------------------------*/
/* Tests                                                                               */
/*-------------------------------------------------------------------------------------*/
int main()
{
    simplePrintLine("Hi", "Hello", "How", "Are", "You");
    print("Hello", 1, 2, 3);
    std::cout << "\nSum: " << add(1, 2, 3, 4, 5);
}