// functions we wish to use with both C and C++
// CSD2125
// 09/23/2021
// compile only with gcc: gcc -std=c11 <additional flags if you wish> -c calc.c

int add(int x, int y) {
  return x+y;
}

int mul(int x, int y) {
  return x*y;
}
