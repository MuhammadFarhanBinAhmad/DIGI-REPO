// functions we wish to use with both C and C++
// CSD2125
// 09/23/2021
// compile only with g++: g++ -std=c++17 <additional flags if you wish> -c drawline.o
#include "drawline.h"

int draw_line(int x, int y) {
    return x+y;
}
