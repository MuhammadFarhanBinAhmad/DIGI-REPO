Student Name:
Muhammad Farhan Bin Ahmad

Project Name:
Blacksmith simulator(Demake)

What I implemented:
I tried to remake my previous VR game project plus some added features. I've implemented:
The blacksmith wizard -
You will be "controlling" him by using his magical machine to spawn different rune types(Weapon,Material and Magic)
to create weapons for your 2 customer, Solana and Antoine, whilst listening to their tales.
Solana and Antoine -
Your 2 customer. Everytime they visit your store, they will request a weapon and it's your job to ensure they get what they
asked for. So do your best :)
The bird -
The blacksmith "familiar". Generally useless. You can control his movement, make him poop and make noise.

Directions (if needed):
Open the "HowToPlay"(directory:"...\Source\Student\Project_1") folder and refer to "Controls.txt" on how to play the blacksmith and the bird and the "RunesCodes.txt"
to know how to spawn certain Rune type on each phase of the weapon creation
The pictures in the folder also represent what weapon the customer wishes for that day. This is to compensate forthe VR aspect 
as originally your suppose to pick up the order given to you by the customer
Every time Antoine(the 2nd customer) leaves the store, the next day starts. There's a total of 4 days

What I liked about the project and framework:
Honestly I had fun making this project as I get to challenge myself to basically remake my entire VR game which took a year 
to make and try to "demake" it.
Framework wise, its not really hard to use and like many things, needs time to understand and get the flow of how it works.

What I disliked about the project and framework:
The framework was limited in certain features and since my project was audio heavy, I had to edit and add some stuff in the
audio manager
I hated that I choose a hard project for myself to make. While it was fun and rewarding at time, I felt i've spent too much time
on this project and that fault solely lays on me. I could fell myself being burnt out by this project and at times, the joy
just turn to sadness as I force myself to get certain features to work.
If I could redo this project, I would most likely make a less ambitious and 
easier project with more modular movement.
I also hate having to extern alot of stuff due not being able to call other object and grabbing certain custome made variables

Any difficulties I experienced while doing the project:
Trying to reframe my previous project game logic and mechanic and try to make it fit and work in this engine.
Due to this project and also my lack of foresight, I could have made some of the node more modular. By doing that I 
would have the need to make a new node for every new action.

Hours spent: 30 hours(too much)

New selector node (name):

New decorator nodes (names):
D_CheckDaySolana
D_CheckDayAntoine
D_CallCustomer
D_CreateWeaponRune
D_CreateMaterialRune
D_CreateMagicRune
D_WantToPoop

10 total nodes (names):
L_GoCounter
L_OrderWeaponSolana
L_OrderWeaponAntoine
L_DialogeSolana
L_DialogeAntoine
L_CheckWeaponSolana
L_CheckWeaponAntoine
L_LeaveStore
L_RotateInCircleRight
L_RotateInCircleLeftUp
L_RotateInCircleRightUp
L_RotateInCircleUp
L_CreateMagicCircle
L_CreatingWeaponRune
L_CreatingMaterialRune
L_CreatingMagicRune
L_MovementControl
L_Gravity
L_PlayBirdNoise
L_Pooping
L_PlayPoopNoise

4 Behavior trees (names):
AntoineAI
SolanaAI
BirdControl
CreateRuneCircle

Extra credit: