# The Rabin Engine v2022.0

## Basic Info:
1. Create a GitHub account using YOUR DIGIPEN EMAIL as the primary email address and YOUR FULL NAME or DIGIPEN USERNAME as the username. We must be able to tell who you are in the class simply by looking at the username and email of the github account.
2. Download/Clone this repository. It is recommmended to CLONE the repo using a git client, because you may then diff againt master for any odd error you encounter. This is a good general practice.
3. Complete the projects as stated in the project rubrics. You should only need to clone once for the entire semester.
4. To recieve extra credit for a bug: please fill out an issue report to this github page following the guidelines in the SAMPLE ISSUE. The issue will then be reviewed by the TA's for verification and eligibility for EC. Extra credit will only be given to those students who follow each of these steps.

Extra credit given cannot push your grade past 100%.
All existing rubric requirements remain, including submission instructions.

### DO NOT SHARE THIS REPO WITH STUDENTS OUTSIDE OF THE CLASS OR DIGIPEN

For any questions or concerns, feel free to contact your TA's.
