#pragma once
#include "BehaviorNode.h"

class L_Pooping:public BaseNode<L_Pooping>
{
protected:
	virtual void on_enter() override;

};
