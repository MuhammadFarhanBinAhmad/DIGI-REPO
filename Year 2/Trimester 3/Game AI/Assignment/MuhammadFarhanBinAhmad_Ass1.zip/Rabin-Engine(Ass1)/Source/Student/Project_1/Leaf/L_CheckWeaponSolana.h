#pragma once
#include "BehaviorNode.h"

class L_CheckWeaponSolana : public BaseNode<L_CheckWeaponSolana>
{
protected:
	virtual void on_enter() override;

	float weapontype;
	float materialtype;
	float magictype;

	bool weaponcorrect;
};
