#include <pch.h>
#include <iostream>
#include <string>
#include "L_OrderWeaponSolana.h"

extern int getCurrentDay();

void L_OrderWeaponSolana::on_enter()
{
	std::wstring path;
	switch (getCurrentDay())
	{
		case 1:
			path += L"Assets\\Audio\\Day1\\Solana\\";

			break;
		case 2:
			path += L"Assets\\Audio\\Day2\\Solana\\";

			break;
		case 3:
			path += L"Assets\\Audio\\Day3\\Solana\\";

			break;
		case 4:
			path += L"Assets\\Audio\\Day4\\Solana\\";
		default:
			break;
	}
	path += L"Intro.wav";

	audioManager->PlaySoundEffect(path);
	timer = audioManager->GetSoundEffectDuration(path) + 3.f;
	BehaviorNode::on_leaf_enter();
	
}

void L_OrderWeaponSolana::on_update(float dt)
{
	timer -= dt;
	if (timer < 0.0f)
	{

		on_success();
	}
	display_leaf_text();

}
