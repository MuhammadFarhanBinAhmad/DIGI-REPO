#pragma once
#include "BehaviorNode.h"

class L_CreateMagicCircle : public BaseNode<L_CreateMagicCircle>
{
protected:
	virtual void on_update(float dt);

	float timer;
	int circleSpawn;
};
