#pragma once
#include "BehaviorNode.h"

class L_CreatingWeaponRune : public BaseNode<L_CreatingWeaponRune>
{
protected:

	virtual void on_update(float dt) override;
	float timer;
	int circleSpawn;
	float weapontype = 0;

};