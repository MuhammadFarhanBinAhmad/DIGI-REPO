#include <pch.h>
#include "L_PlayBirdNoise.h"

void L_PlayBirdNoise::on_enter()
{
	BehaviorNode::on_leaf_enter();
}

void L_PlayBirdNoise::on_update(float dt)
{
	const auto birdnoise = InputHandler::get_current_state(KBKeys::SPACEBAR);

	if (birdnoise == InputHandler::InputState::PRESSED && !soundplayed)
	{
		audioManager->PlaySoundEffect(L"Assets\\Audio\\Quack.wav");
		soundplayed = true;
	}
	if (birdnoise == InputHandler::InputState::RELEASED && soundplayed == true)
	{
		soundplayed = false;
	}

}
