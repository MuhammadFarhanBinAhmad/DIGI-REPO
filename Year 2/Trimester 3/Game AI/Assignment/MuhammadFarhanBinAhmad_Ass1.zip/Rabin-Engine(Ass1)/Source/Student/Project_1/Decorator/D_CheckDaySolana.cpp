#include <pch.h>
#include "D_CheckDaySolana.h"

extern int getCurrentDay();

void D_CheckDaySolana::on_enter()
{
	BehaviorNode::on_enter();
}

void D_CheckDaySolana::on_update(float dt)
{
	BehaviorNode* child = children.front();

	child->tick(dt);

	if (getCurrentDay() <= 4)
	{
		if (child->succeeded() == true)
		{
			child->set_status(NodeStatus::READY);
			on_success();
		}

	}
	display_leaf_text();
}
