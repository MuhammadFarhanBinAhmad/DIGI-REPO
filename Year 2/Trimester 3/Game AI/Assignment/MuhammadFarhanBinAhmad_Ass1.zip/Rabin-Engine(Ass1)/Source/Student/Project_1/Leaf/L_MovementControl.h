#pragma once
#include "BehaviorNode.h"

class L_MovementControl : public BaseNode<L_MovementControl>
{
public:
	L_MovementControl();

	virtual void on_update(float dt);
	float movementSpeed;
};
