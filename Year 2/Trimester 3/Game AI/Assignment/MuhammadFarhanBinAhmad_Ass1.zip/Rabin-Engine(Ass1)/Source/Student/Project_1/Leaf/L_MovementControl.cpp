#include <pch.h>

#include "L_MovementControl.h"
#include "Agent/BehaviorAgent.h"

L_MovementControl::L_MovementControl(): movementSpeed (1.f){}

void L_MovementControl::on_update(float dt)
{
	const auto foward = InputHandler::get_current_state(KBKeys::W);
	const auto back = InputHandler::get_current_state(KBKeys::S);

	const auto left = InputHandler::get_current_state(KBKeys::A);
	const auto right = InputHandler::get_current_state(KBKeys::D);

	const auto elevate = InputHandler::get_current_state(KBKeys::Q);
	const auto lower = InputHandler::get_current_state(KBKeys::E);

	Vec3 curr_pos = agent->get_position();

	if (foward == InputHandler::InputState::PRESSED)
	{
		curr_pos.x += movementSpeed;
		agent->set_position(curr_pos);
	}
	if (back == InputHandler::InputState::PRESSED)
	{
		curr_pos.x -= movementSpeed;
		agent->set_position(curr_pos);
	}

	if (left == InputHandler::InputState::PRESSED)
	{
		curr_pos.z -= movementSpeed;
		agent->set_position(curr_pos);
	}
	if (right == InputHandler::InputState::PRESSED)
	{
		curr_pos.z += movementSpeed;
		agent->set_position(curr_pos);
	}

	if (elevate == InputHandler::InputState::PRESSED)
	{
		curr_pos.y += movementSpeed;
		agent->set_position(curr_pos);
	}
	if (lower == InputHandler::InputState::PRESSED)
	{
		curr_pos.y -= movementSpeed;
		agent->set_position(curr_pos);
	}
}