#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class D_CallCustomer: public BaseNode<D_CallCustomer>
{
protected:
	virtual void on_update(float dt);
	void ResetWeaponMaker();
};
