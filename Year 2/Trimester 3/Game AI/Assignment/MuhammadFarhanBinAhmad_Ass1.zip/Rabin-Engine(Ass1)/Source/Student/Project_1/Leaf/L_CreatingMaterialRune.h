#pragma once
#include "BehaviorNode.h"

class L_CreatingMaterialRune : public BaseNode<L_CreatingMaterialRune>
{
protected:

	virtual void on_update(float dt) override;
	float timer;
	int circleSpawn;
	float materialtype;
};