#pragma once
#include "BehaviorNode.h"

class D_CreateMaterialRune : public BaseNode<D_CreateMaterialRune>
{
protected:
	virtual void on_enter();
	virtual void on_update(float dt);
};