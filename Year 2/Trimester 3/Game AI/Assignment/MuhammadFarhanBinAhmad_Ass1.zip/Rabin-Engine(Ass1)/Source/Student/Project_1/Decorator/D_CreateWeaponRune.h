#pragma once
#include "BehaviorNode.h"

class D_CreateWeaponRune: public BaseNode<D_CreateWeaponRune>
{
protected:
	virtual void on_enter();
	virtual void on_update(float dt);
};