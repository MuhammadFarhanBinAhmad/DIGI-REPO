#pragma once
#include "BehaviorNode.h"

class L_RotateInCircleUp : public BaseNode<L_RotateInCircleUp>
{
public:
	L_RotateInCircleUp();

	float size;
	float val;


	virtual void on_enter();
	virtual void on_update(float dt);
};
