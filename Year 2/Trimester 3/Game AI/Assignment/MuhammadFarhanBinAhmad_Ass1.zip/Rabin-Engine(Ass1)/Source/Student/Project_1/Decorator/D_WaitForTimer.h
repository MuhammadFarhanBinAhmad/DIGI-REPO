#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class D_WaitForTimer : public BaseNode<D_WaitForTimer>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;
	float timer;

};
