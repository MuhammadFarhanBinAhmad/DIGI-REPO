#pragma once
#include "BehaviorNode.h"

class D_CheckDayAntoine : public BaseNode<D_CheckDayAntoine>
{
public:
	virtual void on_enter() override;
	virtual void on_update(float dt);
};