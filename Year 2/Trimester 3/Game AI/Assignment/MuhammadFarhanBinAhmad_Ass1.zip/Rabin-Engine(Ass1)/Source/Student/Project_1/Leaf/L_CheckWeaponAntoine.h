#pragma once
#include "BehaviorNode.h"

class L_CheckWeaponAntoine : public BaseNode<L_CheckWeaponAntoine>
{
protected:
	virtual void on_enter() override;

	float weapontype;
	float materialtype;
	float magictype;

	bool weaponcorrect;
};
