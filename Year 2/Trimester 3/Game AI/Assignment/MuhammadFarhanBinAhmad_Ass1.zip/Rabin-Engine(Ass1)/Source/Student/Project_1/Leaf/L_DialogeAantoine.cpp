#include <pch.h>
#include <iostream>

#include "L_DialogeAntoine.h"

extern int getCurrentDay();
extern bool getCompletedOrder();



void L_DialogeAntoine::on_enter()
{
	BehaviorNode::on_leaf_enter();
	switch (getCurrentDay())
	{
	case 1:
		path += L"Assets\\Audio\\Day1\\Antoine\\";
		break;
	case 2:
		path += L"Assets\\Audio\\Day2\\Antoine\\";
		break;
	case 3:
		path += L"Assets\\Audio\\Day3\\Antoine\\";
		break;
	case 4:
		path += L"Assets\\Audio\\Day4\\Antoine\\";
		break;
	default:
		break;
	}
}

void L_DialogeAntoine::on_update(float dt)
{
	if (current_Dialoge < 4)
	{
		SetDialoge(path, dt);
	}
	else
	{
		on_success();
	}
}
void  L_DialogeAntoine::SetDialoge(const std::wstring& path, float dt)
{
	const auto callcustomer = InputHandler::get_current_state(KBKeys::C);

	std::wstring temppath = path;

	timer -= dt;

	//Play dialoge
	if (dialogeplaying == false)
	{
		current_Dialoge++;
		temppath.clear();
		temppath += path;
		temppath += L"Idle";
		temppath += std::to_wstring(current_Dialoge);
		temppath += L".wav";

		audioManager->PlaySoundEffect(temppath);
		timer = audioManager->GetSoundEffectDuration(temppath) + 3.f;
		dialogeplaying = true;

	}
	if (callcustomer == InputHandler::InputState::PRESSED && getCompletedOrder() == true)
	{
		temppath.clear();
		temppath += path;
		temppath += L"Idle";
		temppath += std::to_wstring(current_Dialoge);
		temppath += L".wav";

		audioManager->StopSoundEffect(temppath);
		current_Dialoge = 5;
		timer = 0.0f;
		dialogeplaying = true;
	}
	if (timer < 0.0f)
	{
		if (current_Dialoge < 4)
		{
			dialogeplaying = false;
		}
	}

	display_leaf_text();
}
