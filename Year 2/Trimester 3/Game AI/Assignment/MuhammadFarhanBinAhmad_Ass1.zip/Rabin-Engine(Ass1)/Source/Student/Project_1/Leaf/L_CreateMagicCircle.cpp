#include <pch.h>

#include "Projects/ProjectOne.h"
#include "L_CreateMagicCircle.h"



void L_CreateMagicCircle::on_update(float dt)
{
	timer -= dt;
	{
		if (timer < 0.0f)
		{
			if (circleSpawn < 12)
			{
				auto circle = agents->create_behavior_agent("MagicCircle", BehaviorTreeTypes::SpawningStartingCircle, Agent::AgentModel::Ball);
				circle->set_position(Vec3(-5.f, 10.f, 75.f));
				circle->set_scaling(0.25f);
				circleSpawn++;
				timer = 0.5f;
			}
			if (circleSpawn == 12)
			{
				//agents->destroy_agent(agents->get_all_agents_by_type("MagicCircle").front());
				on_success();
			}
		}
	}
	display_leaf_text();
}

