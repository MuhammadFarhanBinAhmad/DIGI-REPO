#include <pch.h>

#include "Projects/ProjectOne.h"
#include "L_CreatingMaterialRune.h"

void L_CreatingMaterialRune::on_update(float dt)
{
	const auto Bronze = InputHandler::get_current_state(KBKeys::ONE);
	const auto Iron = InputHandler::get_current_state(KBKeys::TWO);
	const auto Gold = InputHandler::get_current_state(KBKeys::THREE);
	const auto Alloy = InputHandler::get_current_state(KBKeys::FOUR);

	if (Bronze == InputHandler::InputState::PRESSED)
		materialtype = .1f;
	if (Iron == InputHandler::InputState::PRESSED)
		materialtype = .2f;
	if (Gold == InputHandler::InputState::PRESSED)
		materialtype = .3f;
	if (Alloy == InputHandler::InputState::PRESSED)
		materialtype = .4f;

	timer -= dt;
	{
		if (timer < 0.0f)
		{
			if (materialtype > 0)
			{
				if (circleSpawn < 12)
				{
					auto w_circle = agents->create_behavior_agent("MagicCircle", BehaviorTreeTypes::SpawningMaterialCircle, Agent::AgentModel::Ball);
					w_circle->set_position(Vec3(-5.f, 15.f, 75.f));
					w_circle->set_scaling(.25);
					w_circle->set_color(Vec3(0.1f, 0.1f, 0.1f));
					circleSpawn++;
					timer = 0.5f;
				}
				if (circleSpawn == 12)
				{
					auto Rune = agents->create_behavior_agent("MaterialRune", BehaviorTreeTypes::Idle, Agent::AgentModel::Ball);
					Rune->set_position(Vec3(-5.f, 10.f, 75.f));
					Rune->set_color(Vec3(0.f,materialtype, 0.f));
					Rune->set_scaling(.25);
					//agents->destroy_agent(agents->get_all_agents_by_type("MagicCircle").front());
					on_success();
				}
			}

		}
	}
	display_leaf_text();

}

