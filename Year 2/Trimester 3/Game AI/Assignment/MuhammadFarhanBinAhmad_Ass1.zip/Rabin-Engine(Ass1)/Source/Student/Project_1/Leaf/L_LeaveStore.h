#pragma once
#include "BehaviorNode.h"

class L_LeaveStore: public BaseNode<L_LeaveStore>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;

	Vec3 exitlocation;
};
