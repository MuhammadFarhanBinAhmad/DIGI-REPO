#include <pch.h>

#include "L_Gravity.h"
#include "Agent/BehaviorAgent.h"


void L_Gravity::on_update(float dt)
{
	Vec3 curr_pos = agent->get_position();

	curr_pos.y -= gravity;
	agent->set_position(curr_pos);
}