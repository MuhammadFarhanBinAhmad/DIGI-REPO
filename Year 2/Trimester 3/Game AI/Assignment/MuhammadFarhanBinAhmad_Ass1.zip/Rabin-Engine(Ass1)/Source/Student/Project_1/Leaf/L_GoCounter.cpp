#include <pch.h>
#include "L_GoCounter.h"
#include "Agent/BehaviorAgent.h"

extern bool getCompletedOrder();
extern void SetCompletedOrder(bool completed);

void L_GoCounter::on_enter()
{

    targetPoint = Vec3(25.f, 0.f, 90.f);

    BehaviorNode::on_leaf_enter();
}
void L_GoCounter::on_update(float dt)
{
	const auto result = agent->move_toward_point(targetPoint, dt);
    if (result == true)
    {

        on_success();
    }
    display_leaf_text();
}