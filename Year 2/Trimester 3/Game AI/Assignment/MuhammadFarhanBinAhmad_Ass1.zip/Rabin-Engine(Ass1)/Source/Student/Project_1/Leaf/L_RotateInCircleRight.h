#pragma once
#include "BehaviorNode.h"

class L_RotateInCircleRight : public BaseNode<L_RotateInCircleRight>
{
public:
	L_RotateInCircleRight();

	float size;
	float val;


	virtual void on_enter();
	virtual void on_update(float dt);
};
