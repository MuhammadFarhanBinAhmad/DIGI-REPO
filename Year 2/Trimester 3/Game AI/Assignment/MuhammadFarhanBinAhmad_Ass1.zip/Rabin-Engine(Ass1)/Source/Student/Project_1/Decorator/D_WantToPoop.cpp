#include <pch.h>
#include "D_WantToPoop.h"



void D_WantToPoop::on_update(float dt)
{
    const auto poop = InputHandler::get_current_state(KBKeys::P);
    ////fix non repeating
    BehaviorNode* child = children.front();


    if (poop == InputHandler::InputState::PRESSED)
    {
        child->tick(dt);
        child->set_status(NodeStatus::READY);
    }

}
