#include<pch.h>
#include "Projects/ProjectOne.h"
#include "D_CallCustomer.h"
#include "../Agent/BehaviorAgent.h"

bool callCustomer = false;

extern bool getCompletedOrder();
extern void SetCompletedOrder(bool completed);

void D_CallCustomer::on_update(float dt)
{
	const auto callCustomerK = InputHandler::get_current_state(KBKeys::C);

	BehaviorNode* child = children.front();


	if (callCustomerK == InputHandler::InputState::PRESSED && getCompletedOrder() == true)
	{
		callCustomer = true;
	}
	if (callCustomer)
	{
		child->tick(dt);

		if (child->succeeded() == true)
		{
			ResetWeaponMaker();
			on_success();
			callCustomer = false;
			SetCompletedOrder(false);
		}
	}
}
void D_CallCustomer::ResetWeaponMaker()
{


	for (int i = 0; i < agents->get_all_agents_by_type("MagicCircle").size(); i++)
	{
		agents->destroy_agent(agents->get_all_agents_by_type("MagicCircle")[i]);
	}
	auto MagicCircle = agents->create_behavior_agent("SpawnCircle", BehaviorTreeTypes::Idle, Agent::AgentModel::Ball);
	MagicCircle->set_scaling(0.f);
	MagicCircle->set_position(Vec3(-5.f, 10.f, 75.f));
	treeBuilder->build_tree(BehaviorTreeTypes::CreateRuneCircle, MagicCircle);


}