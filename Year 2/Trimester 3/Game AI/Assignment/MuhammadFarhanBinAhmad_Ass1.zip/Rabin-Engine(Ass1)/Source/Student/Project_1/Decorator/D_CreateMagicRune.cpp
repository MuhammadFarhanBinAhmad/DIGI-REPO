#include <pch.h>
#include "D_CreateMagicRune.h"

void D_CreateMagicRune::on_enter()
{
	BehaviorNode::on_enter();
}

void D_CreateMagicRune::on_update(float dt)
{
	BehaviorNode* child = children.front();

	child->tick(dt);
	//Magic should also be true by default(for now)
	if (child->succeeded() == true)
	{
		on_success();
	}


}