#pragma once
#include "BehaviorNode.h"

class D_CheckDaySolana : public BaseNode<D_CheckDaySolana>
{
public:
	virtual void on_enter() override;
	virtual void on_update(float dt);
};