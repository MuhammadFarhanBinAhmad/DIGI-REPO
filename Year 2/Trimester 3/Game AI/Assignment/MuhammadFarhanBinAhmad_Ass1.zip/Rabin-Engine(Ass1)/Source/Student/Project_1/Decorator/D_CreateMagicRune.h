#pragma once
#include "BehaviorNode.h"

class D_CreateMagicRune : public BaseNode<D_CreateMagicRune>
{
protected:
	virtual void on_enter();
	virtual void on_update(float dt);
};