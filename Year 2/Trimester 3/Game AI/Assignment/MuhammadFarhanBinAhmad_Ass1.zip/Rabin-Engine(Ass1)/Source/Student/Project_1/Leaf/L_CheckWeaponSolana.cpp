#include <pch.h>
#include "L_CheckWeaponSolana.h"

extern bool getCompletedOrder();
extern void SetCompletedOrder(bool completed);

extern bool CheckSolanaWeapon();
extern int getCurrentDay();

void L_CheckWeaponSolana::on_enter()
{
	BehaviorNode::on_enter();
	std::wstring path;

	switch (getCurrentDay())
	{
	case 1:
		path += L"Assets\\Audio\\Day1\\Solana\\";
		if (agents->get_all_agents_by_type("WeaponRune").front()->get_color().x == 0.1f &&
			agents->get_all_agents_by_type("MaterialRune").front()->get_color().y == 0.1f &&
			agents->get_all_agents_by_type("MagicRune").front()->get_color().z == 0.1f)
		{
			weaponcorrect = true;
		}
		else
		{
			weaponcorrect = false;
		}
		break;
	case 2:
		path += L"Assets\\Audio\\Day2\\Solana\\";
		if (agents->get_all_agents_by_type("WeaponRune").front()->get_color().x == 0.1f &&
			agents->get_all_agents_by_type("MaterialRune").front()->get_color().y == 0.2f &&
			agents->get_all_agents_by_type("MagicRune").front()->get_color().z == 0.4f)
		{
			weaponcorrect = true;
		}
		else
		{
			weaponcorrect = false;
		}
		break;
	case 3:
		path += L"Assets\\Audio\\Day3\\Solana\\";
		if (agents->get_all_agents_by_type("WeaponRune").front()->get_color().x == 0.1f &&
			agents->get_all_agents_by_type("MaterialRune").front()->get_color().y == 0.4f &&
			agents->get_all_agents_by_type("MagicRune").front()->get_color().z == 0.2f)
		{
			weaponcorrect = true;
		}
		else
		{
			weaponcorrect = false;
		}
		break;
	case 4:
		path += L"Assets\\Audio\\Day4\\Solana\\";
		if (agents->get_all_agents_by_type("WeaponRune").front()->get_color().x == 0.1f &&
			agents->get_all_agents_by_type("MaterialRune").front()->get_color().y == 0.4f &&
			agents->get_all_agents_by_type("MagicRune").front()->get_color().z == 0.3f)
		{
			weaponcorrect = true;
		}
		else
		{
			weaponcorrect = false;
		}
		break;
	default:
		break;
	}
	agents->destroy_agent(agents->get_all_agents_by_type("WeaponRune").front());
	agents->destroy_agent(agents->get_all_agents_by_type("MaterialRune").front());
	agents->destroy_agent(agents->get_all_agents_by_type("MagicRune").front());
	if (weaponcorrect)
	{
		path += L"WC.wav";
		audioManager->PlaySoundEffect(path);
	}
	else
	{
		path += L"WW.wav";
		audioManager->PlaySoundEffect(path);
	}
	on_success();

}
