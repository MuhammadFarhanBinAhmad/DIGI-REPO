#pragma once
#include "BehaviorNode.h"

class L_RotateInCircleRightUp : public BaseNode<L_RotateInCircleRightUp>
{
public:
	L_RotateInCircleRightUp();

	float size;
	float val;


	virtual void on_enter();
	virtual void on_update(float dt);
};
