#pragma once
#include "BehaviorNode.h"

class L_Gravity: public BaseNode<L_Gravity>
{
protected:
	virtual void on_update(float dt);
	float gravity = .01f;
};
