#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class L_OrderWeaponSolana : public BaseNode<L_OrderWeaponSolana>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;

	float timer;
};