#include <pch.h>
#include "D_WaitForTimer.h"

void D_WaitForTimer::on_enter()
{
	timer = 3;
	BehaviorNode::on_enter();
}

void D_WaitForTimer::on_update(float dt)
{
	BehaviorNode* child = children.front();
	
	child->tick(dt);
	timer -= dt;

	if (timer < 0.0f)
	{
		if (child->succeeded() == true)
		{
			on_success();
			timer = 3;

		}
	}


}