#include <pch.h>

#include "Projects/ProjectOne.h"
#include "L_CreatingWeaponRune.h"

void L_CreatingWeaponRune::on_update(float dt)
{
	const auto Knife = InputHandler::get_current_state(KBKeys::ONE);
	const auto Sword = InputHandler::get_current_state(KBKeys::TWO);
	const auto Spear = InputHandler::get_current_state(KBKeys::THREE);

	if (Knife == InputHandler::InputState::PRESSED)
		weapontype = .1f;
	if (Sword == InputHandler::InputState::PRESSED)
		weapontype = .2f;
	if (Spear == InputHandler::InputState::PRESSED)
		weapontype = .3f;

	timer -= dt;
	{
		if (timer < 0.0f)
		{
			if (weapontype > 0)
			{
				if (circleSpawn < 12)
				{
					auto w_circle = agents->create_behavior_agent("MagicCircle", BehaviorTreeTypes::SpawningWeaponCircle, Agent::AgentModel::Ball);
					w_circle->set_position(Vec3(-5.f, 10.f, 75.f));
					w_circle->set_scaling(.25);
					w_circle->set_color(Vec3(0.1f, 0.1f, 0.1f));
					circleSpawn++;
					timer = 0.5f;
				}
				if (circleSpawn == 12)
				{
					auto Rune = agents->create_behavior_agent("WeaponRune", BehaviorTreeTypes::Idle, Agent::AgentModel::Ball);
					Rune->set_position(Vec3(-5.f, 10.f, 75.f));
					Rune->set_color(Vec3(weapontype, 0.f, 0.f));
					Rune->set_scaling(.25);
					//agents->destroy_agent(agents->get_all_agents_by_type("MagicCircle").front());
					on_success();
				}
			}

		}
	}
	display_leaf_text();

}

