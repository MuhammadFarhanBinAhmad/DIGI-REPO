#pragma once
#include "BehaviorNode.h"

class L_PlayBirdNoise : public BaseNode<L_PlayBirdNoise>
{
protected:
    virtual void on_enter() override;
    virtual void on_update(float dt) override;

    bool soundplayed = false;
};