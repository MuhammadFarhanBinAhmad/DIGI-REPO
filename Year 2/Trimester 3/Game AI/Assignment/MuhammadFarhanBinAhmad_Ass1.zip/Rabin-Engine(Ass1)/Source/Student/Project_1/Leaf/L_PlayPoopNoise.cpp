#pragma once
#include <pch.h>
#include "L_PlayPoopNoise.h"


void L_PlayPoopNoise::on_enter()
{
	BehaviorNode::on_leaf_enter();
}


void L_PlayPoopNoise::on_update(float dt)
{
	const auto birdnoise = InputHandler::get_current_state(KBKeys::P);

	if (birdnoise == InputHandler::InputState::PRESSED && !soundplayed)
	{
		audioManager->PlaySoundEffect(L"Assets\\Audio\\Nice.wav");
		soundplayed = true;
	}
	if (birdnoise == InputHandler::InputState::RELEASED && soundplayed == true)
	{
		soundplayed = false;
	}

}