#include <pch.h>
#include "D_CheckDay.h"

std::unique_ptr<AudioManager> dialogue;
extern int getCurrentDay();
extern void addCurrentDay();

void D_CheckDay::on_enter()
{
 //   BehaviorNode::on_enter();
 //   dialogue->SetVolume(.75f);

	//switch (getCurrentDay())
	//{
	//case 1:
	//	dialogue->PlayMusic(L"Assets\\Audio\\Day1\\Antoine\\Intro.wav");
	//	break;
	//case 2:
	//	dialogue->PlayMusic(L"Assets\\Audio\\Day2\\Antoine\\Intro.wav");
	//	break;
	//case 3:
	//	dialogue->PlayMusic(L"Assets\\Audio\\Day3\\Antoine\\Intro.wav");
	//	break;
	//default;
	//}
	//addCurrentDay();
}
