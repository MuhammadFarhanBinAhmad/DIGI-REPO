#include <pch.h>
#include "Projects/ProjectOne.h"
#include "L_LeaveStore.h"

extern int getCurrentDay();


void L_LeaveStore::on_enter()
{

    exitlocation = Vec3(0.f, 0.f, 0.f);

    BehaviorNode::on_leaf_enter();
}
void L_LeaveStore::on_update(float dt)
{
    const auto result = agent->move_toward_point(exitlocation, dt);
    if (result == true)
    {
        if (getCurrentDay() <= 4)
        {
            if (agents->get_all_agents_by_type("Solana").size() == 1)
            {
                agents->destroy_agent(agents->get_all_agents_by_type("Solana").front());
                auto Antoine = agents->create_behavior_agent("Antoine", BehaviorTreeTypes::AntoineAI, Agent::AgentModel::Man);
                Antoine->set_color(Vec3(0.5f, 0.5f, 0.f));   // Set the tree to green
            }
            else if (agents->get_all_agents_by_type("Antoine").size() == 1)
            {
                agents->destroy_agent(agents->get_all_agents_by_type("Antoine").front());
                auto Solana = agents->create_behavior_agent("Solana", BehaviorTreeTypes::SolanaAI, Agent::AgentModel::Man);
                Solana->set_color(Vec3(0.0f, 0.5f, 0.f));   // Set the tree to green
            }
            on_success();
        }

    }
    display_leaf_text();
}