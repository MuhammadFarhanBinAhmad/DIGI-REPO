#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class L_DialogeSolana : public BaseNode<L_DialogeSolana>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;
	void SetDialoge(const std::wstring& path,float dt);

	bool dialogeplaying = false;

	std::wstring path;

	int current_Dialoge;
	float timer;
};
