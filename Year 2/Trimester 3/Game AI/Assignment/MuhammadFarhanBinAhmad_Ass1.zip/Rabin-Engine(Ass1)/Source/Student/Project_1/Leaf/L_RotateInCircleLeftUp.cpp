#include <pch.h>
#include "L_RotateInCircleLeftUp.h"

static Vec3 startpos;
static bool getstartpos;

L_RotateInCircleLeftUp::L_RotateInCircleLeftUp() : size(5), val(0)
{
}
void L_RotateInCircleLeftUp::on_enter()
{
	if (!getstartpos)
	{
		startpos = agent->get_position();
		getstartpos = true;
	}
	BehaviorNode::on_leaf_enter();
}

void L_RotateInCircleLeftUp::on_update(float dt)
{
	Vec3 temp_pos = startpos;
	val += dt;

	float x = -(size * sin(val)) + startpos.x;
	float z = (size * cos(val)) + startpos.z;
	float y = -(size * cos(val)) + startpos.y;
	temp_pos.x = x;
	temp_pos.z = z;
	temp_pos.y = y;
	agent->set_position(temp_pos);

	display_leaf_text();

}