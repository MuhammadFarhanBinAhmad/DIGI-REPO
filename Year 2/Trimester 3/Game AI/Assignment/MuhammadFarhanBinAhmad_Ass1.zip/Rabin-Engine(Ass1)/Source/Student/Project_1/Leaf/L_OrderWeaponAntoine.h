#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class L_OrderWeaponAntoine : public BaseNode<L_OrderWeaponAntoine>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;

	float timer;
};