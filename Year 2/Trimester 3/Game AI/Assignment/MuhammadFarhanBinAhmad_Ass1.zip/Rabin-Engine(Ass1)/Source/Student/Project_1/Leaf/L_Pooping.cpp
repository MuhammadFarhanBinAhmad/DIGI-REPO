#include <pch.h>
#include "Projects/ProjectOne.h"
#include "L_Pooping.h"

void L_Pooping::on_enter()
{
	auto Poop = agents->create_behavior_agent("Poop", BehaviorTreeTypes::BirdPoop, Agent::AgentModel::Ball);
	Poop->set_position(agents->get_all_agents_by_type("Bird").front()->get_position());
	Poop->set_color(Vec3(0.f, 0.f, 0.f));
	Poop->set_scaling(0.1f);
	on_success();
}