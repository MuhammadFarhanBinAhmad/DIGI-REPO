#pragma once
#include "BehaviorNode.h"

class L_PlayPoopNoise: public BaseNode<L_PlayPoopNoise>
{
protected:
    virtual void on_enter() override;
    virtual void on_update(float dt);
    bool soundplayed = false;
};