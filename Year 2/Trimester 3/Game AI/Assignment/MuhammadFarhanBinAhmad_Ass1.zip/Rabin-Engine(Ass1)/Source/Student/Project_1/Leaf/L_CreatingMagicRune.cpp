#include <pch.h>

#include "Projects/ProjectOne.h"
#include "L_CreatingMagicRune.h"

extern void SetCompletedOrder(bool completed);

void L_CreatingMagicRune::on_update(float dt)
{
	const auto None = InputHandler::get_current_state(KBKeys::ONE);
	const auto Ice = InputHandler::get_current_state(KBKeys::TWO);
	const auto Wind = InputHandler::get_current_state(KBKeys::THREE);
	const auto Fire = InputHandler::get_current_state(KBKeys::FOUR);


	if (None == InputHandler::InputState::PRESSED)
		magictype = .1f;
	if (Ice == InputHandler::InputState::PRESSED)
		magictype = .2f;
	if (Wind == InputHandler::InputState::PRESSED)
		magictype = .3f;
	if (Fire == InputHandler::InputState::PRESSED)
		magictype = .4f;

	timer -= dt;
	{
		if (timer < 0.0f)
		{
			if (magictype > 0)
			{
				if (circleSpawn < 12)
				{
					//Rotation direction wrong. need fix
					auto w_circle = agents->create_behavior_agent("MagicCircle", BehaviorTreeTypes::SpawningMagicCircle, Agent::AgentModel::Ball);
					w_circle->set_position(Vec3(-5.f, 10.f, 75.f));
					w_circle->set_scaling(.25);
					w_circle->set_color(Vec3(0.1f, 0.1f, 0.1f));
					circleSpawn++;
					timer = 0.5f;
				}
				if (circleSpawn == 12)
				{
					auto Rune = agents->create_behavior_agent("MagicRune", BehaviorTreeTypes::Idle, Agent::AgentModel::Ball);
					Rune->set_position(Vec3(-5.f, 10.f, 75.f));
					Rune->set_color(Vec3(0.f, 0.f, magictype));
					Rune->set_scaling(.25);
					SetCompletedOrder(true);
					on_success();
				}
			}
		}
	}
	display_leaf_text();

}

