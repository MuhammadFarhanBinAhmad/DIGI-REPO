#include <pch.h>
#include "D_CreateMaterialRune.h"

void D_CreateMaterialRune::on_enter()
{
	BehaviorNode::on_enter();
}

void D_CreateMaterialRune::on_update(float dt)
{
	BehaviorNode* child = children.front();

	child->tick(dt);
	//Material should also be true by default(for now)
	if (child->succeeded() == true)
	{
		on_success();
	}


}