#pragma once

// Include all node headers in this file

// Example Control Flow Nodes
#include "ControlFlow/C_ParallelSequencer.h"
#include "ControlFlow/C_RandomSelector.h"
#include "ControlFlow/C_Selector.h"
#include "ControlFlow/C_Sequencer.h"

// Student Control Flow Nodes


// Example Decorator Nodes
#include "Decorator/D_Delay.h"
#include "Decorator/D_InvertedRepeater.h"
#include "Decorator/D_RepeatFourTimes.h"

// Student Decorator Nodes
#include "Decorator/D_CheckDaySolana.h"
#include "Decorator/D_CheckDayAntoine.h"
#include "Decorator/D_CallCustomer.h"
#include "Decorator/D_CreateWeaponRune.h"
#include "Decorator/D_CreateMaterialRune.h"
#include "Decorator/D_CreateMagicRune.h"
#include "Decorator/D_WantToPoop.h"

// Example Leaf Nodes
#include "Leaf/L_CheckMouseClick.h"
#include "Leaf/L_Idle.h"
#include "Leaf/L_MoveToFurthestAgent.h"
#include "Leaf/L_MoveToMouseClick.h"
#include "Leaf/L_MoveToRandomPosition.h"
#include "Leaf/L_PlaySound.h"

// Student Leaf Nodes
#include "Leaf/L_GoCounter.h"
#include "Leaf/L_OrderWeaponSolana.h"
#include "Leaf/L_OrderWeaponAntoine.h"
#include "Leaf/L_DialogeSolana.h"
#include "Leaf/L_DialogeAntoine.h"
#include "Leaf/L_CheckWeaponSolana.h"
#include "Leaf/L_CheckWeaponAntoine.h"
#include "Leaf/L_LeaveStore.h"
#include "Leaf/L_RotateInCircleRight.h"
#include "Leaf/L_RotateInCircleLeftUp.h"
#include "Leaf/L_RotateInCircleRightUp.h"
#include "Leaf/L_RotateInCircleUp.h"
#include "Leaf/L_CreateMagicCircle.h"
#include "Leaf/L_CreatingWeaponRune.h"
#include "Leaf/L_CreatingMaterialRune.h"
#include "Leaf/L_CreatingMagicRune.h"
#include "Leaf/L_MovementControl.h"
#include "Leaf/L_Gravity.h"
#include "Leaf/L_PlayBirdNoise.h"
#include "Leaf/L_Pooping.h"
#include "Leaf/L_PlayPoopNoise.h"
