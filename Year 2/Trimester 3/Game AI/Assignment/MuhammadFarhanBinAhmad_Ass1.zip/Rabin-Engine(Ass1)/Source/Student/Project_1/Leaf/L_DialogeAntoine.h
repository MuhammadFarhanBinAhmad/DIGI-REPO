#pragma once
#include "BehaviorNode.h"
#include "Misc/NiceTypes.h"

class L_DialogeAntoine : public BaseNode<L_DialogeAntoine>
{
protected:
	virtual void on_enter() override;
	virtual void on_update(float dt) override;
	void SetDialoge(const std::wstring& path, float dt);

	bool dialogeplaying = false;

	std::wstring path;

	int current_Dialoge;
	float timer;
};
