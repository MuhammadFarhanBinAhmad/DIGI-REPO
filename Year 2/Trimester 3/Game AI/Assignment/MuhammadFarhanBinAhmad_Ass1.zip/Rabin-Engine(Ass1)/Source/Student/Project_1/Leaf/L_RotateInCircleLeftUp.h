#pragma once
#include "BehaviorNode.h"

class L_RotateInCircleLeftUp : public BaseNode<L_RotateInCircleLeftUp>
{
public:
	L_RotateInCircleLeftUp();

	float size;
	float val;


	virtual void on_enter();
	virtual void on_update(float dt);
};
