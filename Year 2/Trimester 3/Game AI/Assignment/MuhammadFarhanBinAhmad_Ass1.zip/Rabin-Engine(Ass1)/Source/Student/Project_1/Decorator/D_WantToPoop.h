#pragma once
#include "BehaviorNode.h"

class D_WantToPoop : public BaseNode<D_WantToPoop>
{
public:

protected:
    virtual void on_update(float dt) override;
};