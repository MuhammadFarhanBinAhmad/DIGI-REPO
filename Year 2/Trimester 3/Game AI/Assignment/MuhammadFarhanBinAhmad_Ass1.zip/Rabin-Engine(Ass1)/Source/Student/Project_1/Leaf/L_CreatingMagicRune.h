#pragma once
#include "BehaviorNode.h"

class L_CreatingMagicRune : public BaseNode<L_CreatingMagicRune>
{
protected:

	virtual void on_update(float dt) override;
	float timer;
	int circleSpawn;
	float magictype;
};