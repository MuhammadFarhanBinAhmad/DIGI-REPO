#include <pch.h>
#include "Projects/ProjectOne.h"
#include "Agent/CameraAgent.h"

void SetStore();
static int current_Day = 1;
static bool order_completed = false;

static bool weapon_SolanaCorrect = false;
static bool weapon_AntoineCorrect = false;
static bool solona_LeaveStore = false;

void ProjectOne::setup()
{
    // Create an agent (using the default "Agent::AgentModel::Man" model)
    //auto man = agents->create_behavior_agent("ExampleAgent", BehaviorTreeTypes::Random);

    // You can change properties here or at runtime from a behavior tree leaf node
    // Look in Agent.h for all of the setters, like these:
    // man->set_color(Vec3(1, 0, 1));
    // man->set_scaling(Vec3(7,7,7));
    // man->set_position(Vec3(100, 0, 100));

    // Create an agent with a different 3D model:
    // 1. (optional) Add a new 3D model to the framework other than the ones provided:
    //    A. Find a ".sdkmesh" model or use https://github.com/walbourn/contentexporter
    //       to convert fbx files (many end up corrupted in this process, so good luck!)
    //    B. Add a new AgentModel enum for your model in Agent.h (like the existing Man or Tree).
    // 2. Register the new model with the engine, so it associates the file path with the enum
    //    A. Here we are registering all of the extra models that already come in the package.
    Agent::add_model("Assets\\tree.sdkmesh", Agent::AgentModel::Tree);
    Agent::add_model("Assets\\car.sdkmesh", Agent::AgentModel::Car);
    Agent::add_model("Assets\\bird.sdkmesh", Agent::AgentModel::Bird);
    Agent::add_model("Assets\\ball.sdkmesh", Agent::AgentModel::Ball);
    Agent::add_model("Assets\\hut.sdkmesh", Agent::AgentModel::Hut);

    SetStore();
    // 3. Create the agent, giving it the correct AgentModel type.
    auto Solana = agents->create_behavior_agent("Solana", BehaviorTreeTypes::SolanaAI, Agent::AgentModel::Man);
    //change be use to change behaviourtree
    //treeBuilder->build_tree(BehaviorTreeTypes::Idle, Solana);

    // 4. (optional) You can also set the pitch of the model, if you want it to be rotated differently
    //Antoine->set_pitch(PI / 2);
    // 5. (optional) Set other aspects to make it start out correctly
    Solana->set_color(Vec3(0, 0.5, 0));   // Set the tree to green
    
    // You can technically load any map you want, even create your own map file,
    // but behavior agents won't actually avoid walls or anything special, unless you code
    // that yourself (that's the realm of project 2)
    terrain->goto_map(0);

    // You can also enable the pathing layer and set grid square colors as you see fit.
    // Works best with map 0, the completely blank map
    terrain->pathLayer.set_enabled(true);
    terrain->pathLayer.set_value(0, 0, Colors::Red);

    // Camera position can be modified from this default
    auto camera = agents->get_camera_agent();
    camera->set_position(Vec3(-62.0f, 70.0f, terrain->mapSizeInWorld * 0.5f));
    camera->set_pitch(0.610865); // 35 degrees

    //man->set_position(Vec3(0.f,0.f, 0.f));
    // Sound control (these sound functions can be kicked off in a behavior tree node - see the example in L_PlaySound.cpp)
    audioManager->SetVolume(0.5f);
    //audioManager->PlaySoundEffect(L"Assets\\Audio\\retro.wav");
    audioManager->PlayMusic(L"Assets\\Audio\\weapon_shop.wav");
    // Uncomment for example on playing music in the engine (must be .wav)
    // audioManager->PlayMusic(L"Assets\\Audio\\motivate.wav");
    // audioManager->PauseMusic(...);
    // audioManager->ResumeMusic(...);
    // audioManager->StopMusic(...);
}

void SetStore()
{
    auto Counter = agents->create_behavior_agent("Counter", BehaviorTreeTypes::Idle, Agent::AgentModel::Hut);
    auto MagicCircle = agents->create_behavior_agent("MagicCircle", BehaviorTreeTypes::Idle, Agent::AgentModel::Ball);
    auto bird = agents->create_behavior_agent("Bird", BehaviorTreeTypes::BirdControl, Agent::AgentModel::Bird);

    Counter->set_position(Vec3(25.f, 0, 90.f));
    bird->set_position(Vec3(25.f, 10.f, 75.f));

    bird->set_scaling(0.01f);
    bird->set_color(Vec3(0.f, 1.f, 0.f));

    MagicCircle->set_scaling(0.f);
    treeBuilder->build_tree(BehaviorTreeTypes::CreateRuneCircle, MagicCircle);

}

int getCurrentDay()
{
    return current_Day;
}
void addCurrentDay()
{
    current_Day++;
}
bool getCompletedOrder()
{
    return order_completed;
}
void SetCompletedOrder(bool completed)
{
    order_completed = completed;
}
bool CheckSolanaWeapon()
{
    return weapon_SolanaCorrect;
}
bool CheckAntoineWeapon()
{
    return weapon_AntoineCorrect;
}
void setSolanaLeaveStore(bool left)
{
    solona_LeaveStore = left;
}
bool getSolanaLeaveStore()
{
    return solona_LeaveStore;
}