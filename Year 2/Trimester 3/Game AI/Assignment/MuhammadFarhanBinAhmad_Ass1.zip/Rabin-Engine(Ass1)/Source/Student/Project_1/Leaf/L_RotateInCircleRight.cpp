#include <pch.h>
#include "L_RotateInCircleRight.h"

static Vec3 startpos;
static bool getstartpos;

L_RotateInCircleRight::L_RotateInCircleRight() : size(10), val(0)
{
}
void L_RotateInCircleRight::on_enter()
{
	if (!getstartpos)
	{
		startpos = agent->get_position();
		getstartpos = true;
	}
	BehaviorNode::on_leaf_enter();
}

void L_RotateInCircleRight::on_update(float dt)
{
	Vec3 temp_pos = startpos;
	val += dt;

	float x = (size * sin(val)) + startpos.x;
	float z = (size * cos(val)) + startpos.z;
	temp_pos.x =  x;
	temp_pos.z =  z;

	agent->set_position(temp_pos);

	display_leaf_text();

}