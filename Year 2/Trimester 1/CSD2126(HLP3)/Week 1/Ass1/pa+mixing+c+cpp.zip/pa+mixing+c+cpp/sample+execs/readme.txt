This is the compendium of my executables:
1) sj1.out is C executable [linked using gcc] with C compiled driver.c and C compiled splitter.c
2) sj2.out is C++ executable [linked using g++] with C++ compiled driver.cpp and C++ compiled splitter.cpp
3) sj3.out is C++ executable [linked using g++] with C++ compiled driver.cpp and C compiled splitter.c
4) sj4.out is C++ executable [linked using g++] with C++ compiled driver.cpp and C++ compiled splitter.c
