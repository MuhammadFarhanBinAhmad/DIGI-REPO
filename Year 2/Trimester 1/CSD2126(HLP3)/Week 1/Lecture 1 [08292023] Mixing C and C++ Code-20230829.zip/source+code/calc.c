// pghali for HLP3
// 08/30/2022
// C functions we wish to use in both C only programs and mixed C and C++ programs
// Compile only with gcc: gcc -std=c11 <additional flags if you wish> -c calc.c

int add(int x, int y) {
  return x+y;
}

int mul(int x, int y) {
  return x*y;
}
