#ifndef THREEDDA_H
#define THREEDDA_H

int*** allocate  (int F, int R, int C);
void    deallocate( int ***ppp );

#endif
