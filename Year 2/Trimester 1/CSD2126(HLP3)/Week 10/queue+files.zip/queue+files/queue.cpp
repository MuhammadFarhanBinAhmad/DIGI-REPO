#include "queue.hpp"
// don't include any other headers files [otherwise, the online grader will
// not accept your submission ...]

namespace HLP3 {

// provide implementation using the exact explanation of circular buffers
// that was provided in specs

// for more details, see the interface used by the driver ...

}
