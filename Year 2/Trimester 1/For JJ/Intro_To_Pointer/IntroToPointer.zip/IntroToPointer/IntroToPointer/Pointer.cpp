#include "Pointer.h"

float My_Math::Addition(float* lhs, float* rhs)
{
	return *lhs + *rhs;
}
//Complete other functions below