#pragma once
#include <string>

class My_Math
{
public:
	float Addition(float* lhs, float* rhs);

	//Declare and define a function name Subtraction thats takes in 2 float* value and return float value
	//Declare and define a function name Division thats takes in 2 float* value and return float value
	//Declare and define a function name Multiplication thats takes in 2 float* value and return float value

	//Declare and define a function name Swap thats takes in 2 float* value


	//Declare and define a function name EncodeText thats takes in 1 int value name key and a string* name str
	//Declare and define a function name DecipherText thats takes in 1 int value name key and a string* name str

	float f_01, f_02, f_03,f_04;
	std::string str_01;
	std::string str_02;
	std::string str_03;
	std::string str_04;
};