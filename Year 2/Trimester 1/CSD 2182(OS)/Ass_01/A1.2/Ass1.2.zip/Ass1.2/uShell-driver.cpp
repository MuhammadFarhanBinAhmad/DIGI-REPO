#include "uShell2.h"

int main() {
    // uShell shell{true};
    // shell.run();
    uShell2 shell2{true};
    shell2.run();
}