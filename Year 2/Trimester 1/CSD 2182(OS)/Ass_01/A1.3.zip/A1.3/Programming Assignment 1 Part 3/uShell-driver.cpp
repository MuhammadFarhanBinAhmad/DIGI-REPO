#include "uShell3.h"
int main() {
    uShell3 shell{true};
    shell.run();
}