#include <thread>
#include <cstdlib>
#include <atomic>
#include "semaphore.h"

#define BUF_SIZE 1000
int buf[BUF_SIZE];
Semaphore num_spaces {BUF_SIZE};
Semaphore num_filled {0};
Semaphore buf_fill {1};
void producer(int num)
{	
	for(int i=0; i<num; ++i)
	{
		num_spaces.wait();	
		buf_fill.wait();
		buf[i%BUF_SIZE]=i;
		buf_fill.signal();		
		num_filled.signal();
	}
}

void consumer(int num)
{
	int expected=0;	
	int consume = 0;
	for(int i=0; i<num; ++i)
	{
		num_filled.wait();
		buf_fill.wait();		
		consume = buf[i%BUF_SIZE];	
		buf_fill.signal();				
		num_spaces.signal();
		if(consume!=expected)
		{
			std::cout << std::endl;
     		std::cout << "index: " << i << std::endl;
			std::cout << "consume " << consume  << std::endl;
			std::cout << "Missed " << expected << std::endl;
		}
		expected++;		
	}
}

int main(int argc, char **argv)
{
	if (argc <= 1)	{
		std::cout << "Need one argument" << std::endl;
		return 0;
	}
	
	std::thread t[] { std::thread(producer, std::atoi(argv[1])),
						std::thread(consumer, std::atoi(argv[1]))};
	for(auto & elem : t)
	{
		elem.join();
	}
}