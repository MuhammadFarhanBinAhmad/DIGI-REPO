/* exec.c
** -- eexecuting an existing executable as a child process
** csd2180/2182 9/23
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
//	#include <wait.h>


int main(void) {
  int pid, ppid;

  printf("simple-exec:Original PID is %d\n", getpid());
  /*Exec is not just one call. It's actually a family of calls*/
  //execl("./simple-exec", "whatever", NULL);
  //execl("./a", "william", "hellokitty", "100", "200", "300", NULL);
  //printf("Hello World\n");
  execl("/bin/ls", "ls", NULL);
  //execl("./simple-child", NULL);

  return 0;
}
