#include <stdio.h>
#include <unistd.h>
int main(int argc, char **argv)
{
  int i;
  printf("simple-main:My Process ID is %d\n", getpid());
  printf("%d args\n", argc);
  for(i=0; i<argc; ++i)
    printf("Arg %d:\"%s\"\n", i, argv[i]);
  return 0;
}