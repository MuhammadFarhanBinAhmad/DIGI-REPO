#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
int main()
{
  int descriptor[2];
  const char *haha="Hello World\n";
  // pipe() is a system call returns 2 file descriptors
  //
  pipe(descriptor);
  /* descriptor[0] - for reading end
    ** descriptor[1] - for writing end
    */
  //write(1, haha, 5);
  if(fork()==0)
  {
    /*child writing to writing end*/
    write(descriptor[1], haha, 12);
    return 0;
  }
  else
  {
    char buf[13];
    wait(NULL);
    /*parent reading from reading end*/
    read(descriptor[0], buf, 12);
    buf[12]='\0';
    write(1, buf, 13);
  }
  return 0;
}