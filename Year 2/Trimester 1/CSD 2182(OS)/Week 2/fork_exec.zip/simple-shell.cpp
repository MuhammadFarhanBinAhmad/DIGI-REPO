#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <vector>
#include <sstream>

bool getInput(std::string & input) 
{
  if(!std::getline(std::cin,input))
  { 
    return false;
  }

  if(!input.empty() && input.back() == '\r')
    input.pop_back();
 
  return true;
}

int main()
{
  std::string str;
  std::cout << "$";
  while(true)
  {	  
	std::vector<std::string>	listOfInput;

	if(!getInput(str))
	{	
		continue;
	}
    else
	{
	  std::stringstream ss(str);
	  std::string item;
	  while (std::getline(ss, item, ' '))
		  if(!item.empty())
		  {
			listOfInput.push_back(item);
		  }					
	}		
    std::cin.clear();
    
    if(str.empty())
      continue;

	if(listOfInput[0] == "echo")
    {
	  for(unsigned i=1;i<listOfInput.size()-1;++i)
		std::cout << listOfInput[i] + " ";
	  if(listOfInput.size() > 1)
		std::cout << listOfInput[listOfInput.size()-1] << "\n";	  
    }
	else if(listOfInput[0] == "exit")
    {		
		break;
	}	
    else
    {
      int cpid = fork();
      if(!cpid)
      {	
		//std::cout << "we are here: [" << listOfInput[0].c_str() << std::endl;  
        execlp(listOfInput[0].c_str(), listOfInput[0].c_str(), NULL);
      }
      else
      {
        int status;
        wait(&status);
      }
    }
	listOfInput.clear();
    std::cout << "$";
  }
}