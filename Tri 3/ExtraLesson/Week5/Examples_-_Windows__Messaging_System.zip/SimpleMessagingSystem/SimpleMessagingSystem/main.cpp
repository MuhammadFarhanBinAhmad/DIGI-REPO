#include <iostream>

#include "EventSystem.h"

EventSystem m_EventSystem{};

void TakeDamage()
{
	// Do stuff
	std::cout << "TakeDamage()" << std::endl;
}

void PlayAttackAnim()
{
	// Do stuff
	std::cout << "PlayAttackAnim()" << std::endl;
}

void DecreaseScore()
{
	// Do stuff
	std::cout << "DecreaseScore()" << std::endl;
}

struct Player
{
	void TakeDamage()
	{
		std::cout << "Player::TakeDamage()" << std::endl;
	}
} m_Player{};

struct Enemy
{
	void PlayAttackAnim()
	{
		std::cout << "Enemy::PlayAttackAnim()" << std::endl;
	}
} m_Enemy{};

struct ScoreSystem
{
	void DecreaseScore()
	{
		std::cout << "ScoreSystem::DecreaseScore()" << std::endl;
	}
} m_ScoreSystem{};

int main(void)
{
	// Subscription usually happens at the start of the application
	//m_EventSystem.Subscribe("CollisionEvent", TakeDamage);
	//m_EventSystem.Subscribe("CollisionEvent", PlayAttackAnim);
	//m_EventSystem.Subscribe("CollisionEvent", DecreaseScore);

	m_EventSystem.Subscribe("CollisionEvent", &Player::TakeDamage, &m_Player);
	m_EventSystem.Subscribe("CollisionEvent", &Enemy::PlayAttackAnim, &m_Enemy);
	m_EventSystem.Subscribe("CollisionEvent", &ScoreSystem::DecreaseScore, &m_ScoreSystem);

	// Notifications usually happen during the game loop
	m_EventSystem.Notify("CollisionEvent");

	system("pause");
	return 0;
}
