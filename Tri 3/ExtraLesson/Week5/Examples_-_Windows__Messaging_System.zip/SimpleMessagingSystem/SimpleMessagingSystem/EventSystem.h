#pragma once
#include <functional>
#include <vector>
#include <unordered_map>
#include <assert.h>

class EventCallback
{
	std::vector<std::function<void()>> m_Listeners;

public:
	void Notify()
	{
		for (auto& l : m_Listeners)
		{
			l();
		}
	}

	void SubscribeListener(std::function<void()> function)
	{
		m_Listeners.emplace_back(function);
	}

	template<class T>
	void SubscribeListener(void(T::* function)(), T* owner)
	{
		m_Listeners.emplace_back([function, owner]()
			{
				return (owner->*function)();
			});
	}
};

class EventSystem
{
	std::unordered_map<std::string, EventCallback> m_Events{};

public:
	void Subscribe(const std::string& evtMsg, std::function<void()> function)
	{
		m_Events[evtMsg].SubscribeListener(function);
	}

	template<class T>
	void Subscribe(const std::string& evtMsg, void(T::* function)(), T* owner)
	{
		m_Events[evtMsg].SubscribeListener(function, owner);
	}

	void Notify(const std::string& evtMsg)
	{
		if (!m_Events.contains(evtMsg)) return;
		m_Events[evtMsg].Notify();
	}
};
