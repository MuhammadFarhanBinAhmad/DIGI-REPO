#include <iostream>

int main()
{

	// Do stuff
	std::cout << "Hello world!" << std::endl;

	return 0;
}
