//---------------------------------------------------------
// file:	DancingLines.h
// author:	Justin Chambers
// brief:	Declaration of dancing lines test gamestate
//
// Copyright � 2019 DigiPen, All rights reserved.
//---------------------------------------------------------

// Gamestate Init
void DancingLinesInit();

// Gamestate Update
void DancingLinesUpdate();