                                                                                                                      
  _|_|      _|_|_|    _|_|_|  _|_|_|  _|_|_|            _|      _|                                                    
_|    _|  _|        _|          _|      _|              _|_|  _|_|    _|_|_|  _|_|_|      _|_|_|    _|_|    _|  _|_|  
_|_|_|_|    _|_|    _|          _|      _|  _|_|_|_|_|  _|  _|  _|  _|    _|  _|    _|  _|        _|_|_|_|  _|_|      
_|    _|        _|  _|          _|      _|              _|      _|  _|    _|  _|    _|  _|        _|        _|        
_|    _|  _|_|_|      _|_|_|  _|_|_|  _|_|_|            _|      _|    _|_|_|  _|    _|    _|_|_|    _|_|_|  _|     
---------------------------------------------------------------------------------------------------------------------
Team: Casual Coding Party
Class: CSD1401b

Team Members:
Amadeus Jinhan Chia	  (amadeusjinhan.chia@digipen.edu)
Ang Jiawei Jarrett	  (a.jiaweijarrett@digipen.edu)
Justine Carlo Villa Ilao  (justine.c@digipen.edu)
Muhammad Farhan Bin Ahmad (b.muhammadfarhan@digipen.edu)
Tan Jun Rong		  (t.junrong@digipen.edu)

---------------------------------------------------------------------------------------------------------------------
Overview:
Genre
- Turn based, Survival.

Gameplay Premise
- Defend yourself from the horde of zombies using Tetris blocks to eliminate / block them.

Play Area
- A grid system like Plant vs Zombies.

How to Play
- Players place Tetris blocks on the grid to damage incoming zombies or build walls to stop them.

Game Cycle
- Players will have a hand of 3 Tetris blocks to choose from to place on the grid stop the zombie horde. 
  Everytime a block is placed, the player's turn ends and the Zombie's turn starts. 
  The zombies move left in the grid and more zombies will spawn.

Wave System
- Waves get progessively harder, some waves hit harder than others. Survive 30 waves to win the game!

---------------------------------------------------------------------------------------------------------------------
Controls:
- Mouse only

Damage Zombies / Build Walls
- Left click from hand, drag onto board and release.

Rotate Pieces
- Right click to the piece clockwise.


__ __| |                 |            _|                    |            _)             |
   |   __ \   _` | __ \  |  /  __|   |    _ \   __|   __ \  |  _` | |   | | __ \   _` | |
   |   | | | (   | |   |   < \__ \   __| (   | |      |   | | (   | |   | | |   | (   |_|
  _|  _| |_|\__,_|_|  _|_|\_\____/  _|  \___/ _|      .__/ _|\__,_|\__, |_|_|  _|\__, |_)
                                                     _|            ____/         |___/   