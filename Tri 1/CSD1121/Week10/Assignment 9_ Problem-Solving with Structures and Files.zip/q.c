// TODO: File documentation block required

// TODO: Include all necessary C standard library headers 

// TODO: Definitions of functions declared in q.h go here ...
