/*!
@file q.h
@author MuhammadFarhanBinAhmad(b.muhammadfarhan)
@course IMGD
@section csd1121
@tutorial Assignment 3:Formatted Console Output
@date 12/09/22
@brief This script will convert an inputted fahrenheit value into celsius and kelvin and will list it down in a list*/
void temp_converter(int temp);

