#include <stdio.h>
#include "q.h"
int main(void)
{
    go();
    return 0;
}