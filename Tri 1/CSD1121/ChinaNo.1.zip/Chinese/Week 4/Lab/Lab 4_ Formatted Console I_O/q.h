/*!
@file q.h
@author MuhammadFarhanBinAhmad(b.muhammadfarhan)
@course IMGD
@section csd1121
@Lab 4: Formatted Console I/O
@date 23/09/22
@brief
The user will input in a certain value of money and the system will convert them to its money
type(1000,100,50 etc.) and will out the result
*//*______________________________________________________________________*/
void go(void);
