/*!
@file q.h
@author MuhammadFarhanBinAhmad(b.muhammadfarhan)
@course IMGD
@section csd1121
@Assignment 4: Converting to Roman NumbersVirtual programming lab
@date 21/09/22
@brief
The algorithm belows takes in an int value thats which is being taken from txt file qinput.txt and convert of
them into roman numeral
*//*______________________________________________________________________*/
#pragma once
void decimal_to_roman(int decimal_value);