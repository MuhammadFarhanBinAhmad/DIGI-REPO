g++ -std=c++14 h.cpp jed-lib.cpp -o test.out
