// File header documentation is required!!!

// This file must contain definitions of ALL member functions of class hlp2::punc_stream.

// Don't forget to add the definition of function hlp2::print that was declared in puncstream.hpp!!!
