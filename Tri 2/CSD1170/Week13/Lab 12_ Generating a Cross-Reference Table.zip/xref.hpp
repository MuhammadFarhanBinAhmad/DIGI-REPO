// See specs for complete description of what you need to implement in this file.

// Don't forget documentation: a file header is required; every function and type that you
// define must have appropriate documentation