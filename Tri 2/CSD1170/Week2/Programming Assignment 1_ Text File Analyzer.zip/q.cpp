// You must only include the following header files ...
#include <iostream>
#include <iomanip>
#include <fstream>

// Important notes:

// The auto grader will look for exactly the above three includes.
// If there any additional includes, it will not compile your file.
// The auto grade will not accept any functions not declared in
// these three header files [even in comments]!!!
// You're warned!!!

namespace hlp2 {
  // provide definition of q here ...
}
