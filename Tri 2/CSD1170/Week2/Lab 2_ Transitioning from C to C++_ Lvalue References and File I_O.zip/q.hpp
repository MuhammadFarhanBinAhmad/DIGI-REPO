#ifndef Q_HPP
#define Q_HPP

// This file can have only one include directive ...

// required since type Tsunami has data member of type std::string
#include <string> // don't remove

namespace hlp2 {
  
  struct Tsunami {
    // declare data members ...

  };
  
  // declaration of interface functions ...
  
  
} // end namespace hlp2
#endif
