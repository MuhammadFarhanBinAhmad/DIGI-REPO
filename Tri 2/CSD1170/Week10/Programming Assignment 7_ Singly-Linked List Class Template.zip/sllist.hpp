// File header documentation is required!!!

// Follow other guidelines and practices from previous assessments

// Don't include <forward_list> and <list>; otherwise your submission will not compile!!!
// Therefore, remove the above line!!!

// add this non-member, non-friend function template declaration:
template <typename T>
std::ostream& operator<<(std::ostream& os, sllist<T> const& list);
