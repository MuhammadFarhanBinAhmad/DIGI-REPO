#pragma once

void component_level_init(void);
void component_level_update(void);
void component_level_exit(void);