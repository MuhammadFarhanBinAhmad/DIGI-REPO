#pragma once
typedef struct object object;
typedef enum component_type
{
	NONE_COMPONENT,
	POSITION,
	CIRCLE_COLLIDER,
	TIMER,
	RENDER,
	SPECTATOR,
	MESSAGE,
	CONTROLLER
}component_type;





