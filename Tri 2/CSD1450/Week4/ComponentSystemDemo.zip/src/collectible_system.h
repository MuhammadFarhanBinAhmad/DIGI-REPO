#pragma once

void collectible_system_init();
void collectible_system_update();